import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QrService } from '../services/qr.service'; // Servicio de QR

@Component({
  selector: 'app-asistencia',
  templateUrl: './asistencia.page.html',
  styleUrls: ['./asistencia.page.scss'],
})
export class AsistenciaPage implements OnInit {
  qrCodeUrl: string = ''; // Para almacenar la URL del QR generado

  constructor(private qrService: QrService) { }

  ngOnInit() {
    // Verifica si se ha pasado un QR desde otra página
    this.generateQRCode();
  }

  generateQRCode() {
    const dataToEncode = `http://192.168.50.241:8101/first-page`; // URL del login
    this.qrService.generateQRCode(dataToEncode).subscribe(
      (qrBlob) => {
        // Convertir el blob a una URL para usarlo en el src de la imagen
        this.qrCodeUrl = URL.createObjectURL(qrBlob);
        console.log('QR generado:', this.qrCodeUrl); // Verificar la URL en la consola
      },
      (error) => {
        console.error('Error al generar el QR:', error);
      }
    );
  }

  

  
}
