import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { AsistenciaPage } from './asistencia.page';

import { AsistenciaPageRoutingModule } from './asistencia-routing.module'; // Asegúrate de tener el enrutamiento adecuado

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AsistenciaPageRoutingModule  // Importa el módulo de enrutamiento de la página
  ],
  declarations: [AsistenciaPage]
})
export class AsistenciaPageModule {}
