import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { QrService } from '../services/qr.service';

@Component({
  selector: 'app-second-page',
  templateUrl: './second-page.page.html',
  styleUrls: ['./second-page.page.scss'],
})

export class SecondPagePage implements OnInit {
  username: string = ''; // Propiedad para almacenar el username
  qrCodeUrl: string = ''; // Para almacenar el QR generado

    constructor(private router: Router, private qrService: QrService) {}


  ngOnInit() {
    // Accede al estado pasado desde la primera página
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      this.username = navigation.extras.state['username'];
    }
  }

   // Método para navegar a la página de asistencia
   navigateToAsistencia() {
    this.router.navigate(['/asistencia']);
  }
  
}