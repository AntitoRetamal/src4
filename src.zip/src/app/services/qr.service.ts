import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class QrService {
  constructor(private http: HttpClient) {}

  generateQRCode(data: string): Observable<any> {
    const apiUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(data)}&size=200x200`;
    
    // Cambiar para obtener la imagen como blob
    return this.http.get(apiUrl, { responseType: 'blob' });
  }
}

